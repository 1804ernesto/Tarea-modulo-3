/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bibliotecavirtual;

/**
 *
 * @author DELL
 */
import java.util.ArrayList;
import java.util.Scanner;

class Libro {
    private String titulo;
    private String autor;
    private int anioPublicacion;
    private String genero;
    private boolean disponible; // true si el libro está disponible, false si está prestado

    // Constructor
    public Libro(String titulo, String autor, int anioPublicacion, String genero) {
        this.titulo = titulo;
        this.autor = autor;
        this.anioPublicacion = anioPublicacion;
        this.genero = genero;
        this.disponible = true; // Por defecto, el libro está disponible al crearse
    }

    // Getters y Setters
    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public int getAnioPublicacion() {
        return anioPublicacion;
    }

    public String getGenero() {
        return genero;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void prestar() {
        if (disponible) {
            disponible = false;
        } else {
            System.out.println("El libro ya está prestado.");
        }
    }

    public void devolver() {
        if (!disponible) {
            disponible = true;
        } else {
            System.out.println("El libro ya estaba disponible.");
        }
    }

    public void mostrarInfo() {
        System.out.println("Título: " + titulo);
        System.out.println("Autor: " + autor);
        System.out.println("Año de publicación: " + anioPublicacion);
        System.out.println("Género: " + genero);
        System.out.println("Disponibilidad: " + (disponible ? "Disponible" : "Prestado"));
    }
}

class Biblioteca {
    private ArrayList<Libro> libros;

    public Biblioteca() {
        libros = new ArrayList<>();
    }

    // Método para agregar libros a la biblioteca
    public void agregarLibro(Libro libro) {
        libros.add(libro);
    }

    // Método para obtener la lista de libros
    public ArrayList<Libro> getLibros() {
        return libros;
    }

    // Método para buscar libros por título
    public void buscarPorTitulo(String titulo) {
        boolean encontrado = false;
        for (Libro libro : libros) {
            if (libro.getTitulo().equalsIgnoreCase(titulo)) {
                libro.mostrarInfo();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron libros con el título: " + titulo);
        }
    }

    // Método para buscar libros por autor
    public void buscarPorAutor(String autor) {
        boolean encontrado = false;
        for (Libro libro : libros) {
            if (libro.getAutor().equalsIgnoreCase(autor)) {
                libro.mostrarInfo();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("No se encontraron libros del autor: " + autor);
        }
    }

    // Método para mostrar todos los libros disponibles
    public void mostrarLibrosDisponibles() {
        boolean hayLibrosDisponibles = false;
        for (Libro libro : libros) {
            if (libro.isDisponible()) {
                libro.mostrarInfo();
                System.out.println();
                hayLibrosDisponibles = true;
            }
        }
        if (!hayLibrosDisponibles) {
            System.out.println("No hay libros disponibles en la biblioteca.");
        }
    }
}

public class BibliotecaVirtual {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();

        // Agregar algunos libros para probar
        biblioteca.agregarLibro(new Libro("El Quijote", "Miguel de Cervantes", 1605, "Novela"));
        biblioteca.agregarLibro(new Libro("1984", "George Orwell", 1949, "Distopía"));
        biblioteca.agregarLibro(new Libro("Cien años de soledad", "Gabriel García Márquez", 1967, "Realismo mágico"));

        int opcion;
        do {
            System.out.println("Menú:");
            System.out.println("1. Agregar libro");
            System.out.println("2. Buscar libro por título");
            System.out.println("3. Buscar libro por autor");
            System.out.println("4. Prestar libro");
            System.out.println("5. Devolver libro");
            System.out.println("6. Mostrar libros disponibles");
            System.out.println("7. Salir");
            System.out.print("Elige una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar el buffer de entrada

            switch (opcion) {
                case 1:
                    // Agregar libro
                    System.out.print("Título: ");
                    String titulo = scanner.nextLine();
                    System.out.print("Autor: ");
                    String autor = scanner.nextLine();
                    System.out.print("Año de publicación: ");
                    int anio = scanner.nextInt();
                    scanner.nextLine(); // Limpiar el buffer de entrada
                    System.out.print("Género: ");
                    String genero = scanner.nextLine();
                    biblioteca.agregarLibro(new Libro(titulo, autor, anio, genero));
                    System.out.println("Libro agregado exitosamente.");
                    break;
                case 2:
                    // Buscar por título
                    System.out.print("Introduce el título del libro: ");
                    String tituloBusqueda = scanner.nextLine();
                    biblioteca.buscarPorTitulo(tituloBusqueda);
                    break;
                case 3:
                    // Buscar por autor
                    System.out.print("Introduce el autor del libro: ");
                    String autorBusqueda = scanner.nextLine();
                    biblioteca.buscarPorAutor(autorBusqueda);
                    break;
                case 4:
                    // Prestar libro
                    System.out.print("Introduce el título del libro que deseas prestar: ");
                    String tituloPrestar = scanner.nextLine();
                    for (Libro libro : biblioteca.getLibros()) {
                        if (libro.getTitulo().equalsIgnoreCase(tituloPrestar)) {
                            libro.prestar();
                            break;
                        }
                    }
                    break;
                case 5:
                    // Devolver libro
                    System.out.print("Introduce el título del libro que deseas devolver: ");
                    String tituloDevolver = scanner.nextLine();
                    for (Libro libro : biblioteca.getLibros()) {
                        if (libro.getTitulo().equalsIgnoreCase(tituloDevolver)) {
                            libro.devolver();
                            break;
                        }
                    }
                    break;
                case 6:
                    // Mostrar libros disponibles
                    biblioteca.mostrarLibrosDisponibles();
                    break;
                case 7:
                    System.out.println("¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }

        } while (opcion != 7);

        scanner.close();
    }
}
